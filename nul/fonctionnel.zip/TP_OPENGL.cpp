///////////////////////////////////////////////////////////////////////////////
// Imagina
// ----------------------------------------------------------------------------
// IN - Synth�se d'images - Mod�lisation g�om�trique
// Auteur : Gilles Gesqui�re
// ----------------------------------------------------------------------------
// Base du TP 1
// programme permettant de cr�er des formes de bases.
// La forme repr�sent�e ici est un polygone blanc dessin� sur un fond rouge
///////////////////////////////////////////////////////////////////////////////  

#include <stdio.h>     
#include <stdlib.h>     
#include <math.h>
#include <iostream>
#include <vector>
#include "GL/freeglut.h"
//#include "GL/glad.h"
#include <fstream>

/* Dans les salles de TP, vous avez g�n�ralement acc�s aux glut dans C:\Dev. Si ce n'est pas le cas, t�l�chargez les .h .lib ...
Vous pouvez ensuite y faire r�f�rence en sp�cifiant le chemin dans visual. Vous utiliserez alors #include <glut.h>. 
Si vous mettez glut dans le r�pertoire courant, on aura alors #include "glut.h" 
*/


#include "CVector.h"
#include "CPoint.h"
#include "Voxel.h"

using namespace std;

// D�finition de la taille de la fen�tre
#define WIDTH  480

#define HEIGHT 480

// D�finition de la couleur de la fen�tre
#define RED   0
#define GREEN 0
#define BLUE  0
#define ALPHA 1


// Touche echap (Esc) permet de sortir du programme
#define KEY_ESC 27
#define PRECISION 0.1
double nbM = 8;
double nbN = 8;
double ortho1 = -21.0;
double ortho2 = 21.0;
double ortho3 = -21.0;
double ortho4 = 21.0;
double ortho5 = -21.0;
double ortho6 = 21.0;

// Ent�tes de fonctions
void init_scene();
void render_scene();
GLvoid initGL();
GLvoid window_display();
GLvoid window_reshape(GLsizei width, GLsizei height); 
GLvoid window_key(unsigned char key, int x, int y); 

struct mesh
{
    float * coordinates;
    int * indices;
    int nbPoints;
    int nbTriangles;
};

int main(int argc, char **argv) 
{  
    // initialisation  des param�tres de GLUT en fonction
    // des arguments sur la ligne de commande
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA);

    // d�finition et cr�ation de la fen�tre graphique, ainsi que son titre
    glutInitWindowSize(WIDTH, HEIGHT);
    glutInitWindowPosition(0, 0);
    glutCreateWindow("Premier exemple : carr�");

    // initialisation de OpenGL et de la sc�ne
    initGL();
    init_scene();

    // choix des proc�dures de callback pour
    // le trac� graphique
    glutDisplayFunc(&window_display);
    // le redimensionnement de la fen�tre
    glutReshapeFunc(&window_reshape);
    // la gestion des �v�nements clavier
    glutKeyboardFunc(&window_key);

    // la boucle prinicipale de gestion des �v�nements utilisateur
    glutMainLoop();

    return 1;
}

// initialisation du fond de la fen�tre graphique : noir opaque
GLvoid initGL() 
{
    glClearColor(RED, GREEN, BLUE, ALPHA);
}

// Initialisation de la scene. Peut servir � stocker des variables de votre programme
// � initialiser
void init_scene()
{
}

// fonction de call-back pour l�affichage dans la fen�tre

GLvoid window_display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

    // C'est l'endroit o� l'on peut dessiner. On peut aussi faire appel
    // � une fonction (render_scene() ici) qui contient les informations
    // que l'on veut dessiner
    render_scene();

    // trace la sc�ne grapnique qui vient juste d'�tre d�finie
    glFlush();
}

// fonction de call-back pour le redimensionnement de la fen�tre

GLvoid window_reshape(GLsizei width, GLsizei height)
{  
    glViewport(0, 0, width, height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    // ici, vous verrez pendant le cours sur les projections qu'en modifiant les valeurs, il est
    // possible de changer la taille de l'objet dans la fen�tre. Augmentez ces valeurs si l'objet est
    // de trop grosse taille par rapport � la fen�tre.
    glOrtho(-2.0, 2.0, -2.0, 2.0, -2.0, 2.0);


    // toutes les transformations suivantes s�appliquent au mod�le de vue
    glMatrixMode(GL_MODELVIEW);
}

// fonction de call-back pour la gestion des �v�nements clavier

GLvoid window_key(unsigned char key, int x, int y) 
{  
    switch (key) {
    case KEY_ESC:
        exit(1);
        break;

    case '+':
        nbM++;
        nbN++;
        glutPostRedisplay();
        break;

    case '-':
        if (nbM > 4) nbM--;
        if (nbN > 3) nbN--;
        glutPostRedisplay();
        break;

    case 'z':;
        ortho4++;
        ortho5++;
        ortho6++;
        glutPostRedisplay();
        break;

    case 's':
        ortho4--;
        ortho5--;
        ortho6--;
        glutPostRedisplay();
        break;

    default:
        printf ("La touche %d n�est pas active.\n", key);
        break;
    }
}
CPoint somme(vector<double> asum, vector<CPoint> point){
    double resultx = 0;
    double resulty = 0;
    double resultz = 0;

    CPoint final;

    for (int i = 0;i < asum.size(); i++){
        resultx+=asum[i]*point[i].getX();
        cout << resultx << endl;
        resulty+=asum[i]*point[i].getY();
        resultz+=asum[i]*point[i].getZ();
    }
    final.setX(resultx);
    final.setY(resulty);
    final.setZ(resultz);

    return final;
}

void DrawCurve(vector<CPoint> TabPoint){
    glBegin(GL_LINE_STRIP);
    for (int i = 0; i < TabPoint.size(); i++){
        glVertex3f(TabPoint[i].getX(),TabPoint[i].getY(),TabPoint[i].getZ());
    }
    glEnd();
}

void DrawPoly(vector<CPoint> TabPoint){
    glBegin(GL_POLYGON);
    for (int i = 0; i < TabPoint.size(); i++){
        glVertex3f(TabPoint[i].getX(),TabPoint[i].getY(),TabPoint[i].getZ());
    }
    glEnd();
}

unsigned fact(unsigned x){
    if (x==0) return 1;
    return x*fact(x-1);
}
vector<CPoint> HermiteCubicCurve(CPoint p0,CPoint p1, CVector v0, CVector v1, long nbU){

    vector<CPoint> Pointst;

    for (int i = 0; i < nbU; i++){
        CPoint tmp;

        double j = (double) i/nbU;

        float F1 = 2*pow(j,3)-3*pow(j,2)+1;
        float F2 = -2*pow(j,3)+3*pow(j,2);
        float F3 = pow(j,3)-2*pow(j,2)+j;
        float F4 = pow(j,3)-pow(j,2);

        tmp.setX(F1*p0.getX()+F2*p1.getX()+F3*v0.getX()+F4*v1.getX());
        tmp.setY(F1*p0.getY()+F2*p1.getY()+F3*v0.getY()+F4*v1.getY());
        tmp.setZ(F1*p0.getZ()+F2*p1.getZ()+F3*v0.getZ()+F4*v1.getZ());

        cout << tmp.getX() << tmp.getY() << tmp.getZ() << endl;

        Pointst.push_back(tmp);
    }

    return Pointst;

}
vector<CPoint> BezierCurveByBernstein(vector<CPoint> tabControl,long nbU){
    vector<CPoint> final;
    for (int i = 0; i < nbU; i++){
        double k = (double) i/nbU;
        vector<double> polynomes;
        for (int j = 0; j < tabControl.size(); j++){
            double f1 = (double) fact(tabControl.size()-1)/(fact(j)*fact(tabControl.size()-1 -j));
            double f2 = (double) pow(1-k,tabControl.size()-1 -j);

            double tmp = f1*pow(k,j)*f2;
            cout << tmp << endl;
            polynomes.push_back(tmp);
        }

        CPoint x;
        x = somme(polynomes,tabControl);
        final.push_back(x);
    }

    return final;
}

vector<CPoint> BezierCurveByCasteljau(vector<CPoint> points,long nbu)
{
    vector<CPoint> bezierPoints;

    for(double t = 0 ; t < nbu ; t++)
    {
        double k = (double) t/nbu;

        vector<CPoint> tmp1 = points;

        while(tmp1.size()>1)
        {
            vector<CPoint> tmp2;

            for(int i = 0 ; i<tmp1.size()-1 ; i++)
            {
                CPoint Ptmp1 = tmp1[i];
                CPoint Ptmp2 = tmp1[i+1];

                CPoint tmp = CPoint(Ptmp1.getX() * (1-k) + Ptmp2.getX() * k,Ptmp1.getY() * (1-k) + Ptmp2.getY() * k,0);
                tmp.drawPoint();
                tmp2.push_back(tmp);
            }

            tmp1 = tmp2;
        }

        bezierPoints.push_back(tmp1[0]);
    }

    return bezierPoints;
}
vector<vector<CPoint> > traceSurfaceCylindrique(vector<CPoint> points, CVector v1, long nbv,long nbu){
    vector<vector<CPoint> > result;
    vector<CPoint> cptmp;

    vector<CPoint> bezier = BezierCurveByBernstein(points,nbu);

    for (int j = 0; j < bezier.size(); j++){
        CPoint tmp1 = CPoint(bezier[j].getX()+v1.getX(),bezier[j].getY()+v1.getY(),0);
        cptmp.push_back(bezier[j]);
        cptmp.push_back(tmp1);
        result.push_back(cptmp);
        cptmp.clear();
    }

    vector<CPoint> copy = points;

    double range = (double) 1/nbv;
    for (int i = 0; i < nbv; i++){
        bezier = BezierCurveByBernstein(copy,nbu);
        for (int l = 0; l < copy.size(); l++){
            copy[l].setX(copy[l].getX()+range);
            copy[l].setY(copy[l].getX()+range);
        }

        result.push_back(bezier);
        bezier.clear();
    }

    return result;
}

double rand_float(double a, double b) {
    return ((double)rand() / RAND_MAX) * (b - a) + a;
}

void Cylindre(){
    double h = 20.0;
    double r = 10.0;
    int nbMeridiens = 10;

    vector<CPoint> tmp1;
    vector<CPoint> tmp2;
    vector<vector<CPoint> > result;

    for(double i = 0.0; i < nbMeridiens; i++){
        double omega = 2.0 * (atan(1) * 4) *  i / nbMeridiens;

        double x = r * sin(omega);
        double y = r * cos(omega);
        double z = 0.0;
        double z2 = h;

        CPoint p = CPoint(x,y,z);
        CPoint p2 = CPoint(x,y,z2);

        tmp1.push_back(p);
        tmp2.push_back(p2);


    }
    result.push_back(tmp1);

    result.push_back(tmp2);

    for (int i = 0; i < result[0].size() - 1 ; i++){
        glColor3f(rand_float(0.0,1.0), rand_float(0.0,1.0), rand_float(0.0,1.0));
        glBegin(GL_POLYGON);
        result[0][i].drawPoint();
        result[1][i].drawPoint();
        result[1][i+1].drawPoint();
        result[0][i+1].drawPoint();
        glEnd();

    }

    glBegin(GL_POLYGON);
    result[0][0].drawPoint();
    result[0][result[0].size() - 1].drawPoint();
    result[1][result[0].size() - 1].drawPoint();
    result[1][0].drawPoint();
    glEnd();

    glColor3f(rand_float(0.0,1.0), rand_float(0.0,1.0), rand_float(0.0,1.0));
    glBegin(GL_POLYGON);
    for (int i = 0; i < result[0].size(); i++){
        result[0][i].drawPoint();
    }

    glEnd();
    glBegin(GL_POLYGON);
    result[0][0].drawPoint();
    result[0][result.size()- 1].drawPoint();
    result[0][result.size()- 2].drawPoint();
    glEnd();



}

void Cone(int n){
    int rayon = 15;
    int hauteur = 20;

    vector<CPoint> result;
    result.push_back(CPoint(0,0,20));

    for(double i = 0.0; i < n; i++){
        double omega = 2.0 * (atan(1) * 4) *  i / n;

        double x = rayon * sin(omega);
        double y = rayon * cos(omega);
        double z = 20+hauteur;

        CPoint b = CPoint(x,y,z);

        result.push_back(b);
    }

    for (int i = 0; i < result.size() - 1 ; i++){
        glColor3f(rand_float(0.0,1.0), rand_float(0.0,1.0), rand_float(0.0,1.0));
        glBegin(GL_POLYGON);
        result[0].drawPoint();
        result[i].drawPoint();
        result[i+1].drawPoint();
        glEnd();
    }

    glColor3f(rand_float(0.0,1.0), rand_float(0.0,1.0), rand_float(0.0,1.0));
    glBegin(GL_POLYGON);
    result[0].drawPoint();
    result[1].drawPoint();
    result[result.size() -1].drawPoint();
    glEnd();

}
void Sphere(int rayon, double nbMeridiens, double nbParallelles){
    vector<vector<CPoint> > result;

    CPoint nord = CPoint(0,rayon,0);
    CPoint sud = CPoint(0,-rayon,0);
    glBegin(GL_POINTS);
    glColor3f(rand_float(0.0,1.0), rand_float(0.0,1.0), rand_float(0.0,1.0));
    glColor3f(rand_float(0.0,1.0), rand_float(0.0,1.0), rand_float(0.0,1.0));
    sud.drawPoint();
    glColor3f(1.0,1.0,1.0);
    glEnd();


    for (int i = 0; i < nbParallelles; i++){
        double phi = (atan(1) * 4) * i / nbParallelles;
        vector<CPoint> tmp1;
        for (int j = 0; j < nbMeridiens; j++){
            double the = 2 * (atan(1) * 4) * j / nbMeridiens;
            double x = rayon * sin(phi) * cos(the);
            double z = rayon * sin(phi) * sin(the);
            double y = rayon * cos(phi);
            CPoint t = CPoint(x,y,z);
            glBegin(GL_POINTS);
            t.drawPoint();
            glEnd();
            tmp1.push_back(t);
        }
        result.push_back(tmp1);
        tmp1.clear();
    }


    for (int i = 0; i < result.size() -1 ; i++){
        for (int j = 0;j < result[i].size() - 1 ; j++){
            glColor3f(rand_float(0.0,1.0), rand_float(0.0,1.0), rand_float(0.0,1.0));
            glBegin(GL_POLYGON);
            result[i][j].drawPoint();
            result[i+1][j].drawPoint();
            result[i+1][j+1].drawPoint();
            result[i][j+1].drawPoint();
            glEnd();
        }

        glColor3f(rand_float(0.0,1.0), rand_float(0.0,1.0), rand_float(0.0,1.0));
        glBegin(GL_POLYGON);
        result[i][0].drawPoint();
        result[i+1][0].drawPoint();
        result[i+1][nbM - 1].drawPoint();
        result[i][nbM - 1].drawPoint();
        glEnd();
    }

    for (int i = 0; i < nbMeridiens ; i++){
        glColor3f(rand_float(0.0,1.0), rand_float(0.0,1.0), rand_float(0.0,1.0));
        glBegin(GL_POLYGON);
        nord.drawPoint();
        result[0][i].drawPoint();
        result[0][i+1].drawPoint();
        glEnd();
    }

    glBegin(GL_POLYGON);
    nord.drawPoint();
    result[0][0].drawPoint();
    result[0][nbParallelles -1 ].drawPoint();
    glEnd();

    for (int i = 0; i < nbMeridiens ; i++){
        glColor3f(rand_float(0.0,1.0), rand_float(0.0,1.0), rand_float(0.0,1.0));
        glBegin(GL_POLYGON);
        sud.drawPoint();
        result[nbParallelles - 1][i].drawPoint();
        result[nbParallelles - 1][i+1].drawPoint();
        glEnd();
    }
    glBegin(GL_POLYGON);
    sud.drawPoint();
    result[nbParallelles -1 ][0].drawPoint();
    result[nbParallelles -1 ][nbMeridiens - 1].drawPoint();
    glEnd();

}
/* 
void DisplayVoxel(double length,CPoint Centre){
    vector <CPoint> VoxelP1;

    VoxelP1.push_back(CPoint(Centre.getX() + length / 2, Centre.getY() + length / 2, Centre.getZ() + length / 2));
    VoxelP1.push_back(CPoint(Centre.getX() + length / 2, Centre.getY() - length / 2, Centre.getZ() + length / 2));
    VoxelP1.push_back(CPoint(Centre.getX() - length / 2, Centre.getY() - length / 2, Centre.getZ() + length / 2));
    VoxelP1.push_back(CPoint(Centre.getX() - length / 2, Centre.getY() + length / 2, Centre.getZ() + length / 2));
    VoxelP1.push_back(CPoint(Centre.getX() + length / 2, Centre.getY() + length / 2, Centre.getZ() + length / 2));

    DrawPoly(VoxelP1);

    vector <CPoint> VoxelP2;

    VoxelP2.push_back(CPoint(Centre.getX() + length / 2, Centre.getY() + length / 2, Centre.getZ() - length / 2));
    VoxelP2.push_back(CPoint(Centre.getX() + length / 2, Centre.getY() - length / 2, Centre.getZ() - length / 2));
    VoxelP2.push_back(CPoint(Centre.getX() - length / 2, Centre.getY() - length / 2, Centre.getZ() - length / 2));
    VoxelP2.push_back(CPoint(Centre.getX() - length / 2, Centre.getY() + length / 2, Centre.getZ() - length / 2));
    VoxelP2.push_back(CPoint(Centre.getX() + length / 2, Centre.getY() + length / 2, Centre.getZ() - length / 2));

    DrawPoly(VoxelP2);

    for (unsigned i (0); i < VoxelP1.size() - 1; ++i) {
        glBegin(GL_POLYGON);
        glVertex3f(VoxelP1[i].getX(), VoxelP1[i].getY(), VoxelP1[i].getZ());
        glVertex3f(VoxelP2[i].getX(), VoxelP2[i].getY(), VoxelP2[i].getZ());
        glVertex3f(VoxelP2[i+1].getX(), VoxelP2[i+1].getY(), VoxelP2[i+1].getZ());
        glVertex3f(VoxelP1[i+1].getX(), VoxelP1[i+1].getY(), VoxelP1[i+1].getZ());
        glEnd();
    }

}

/* */

void displayVoxelRecSphere(Voxel* v, CPoint* ct, double ray,double reso, double i) {
  if(i<reso)
  {
    for(int k=0; k<8; k++)
    {
      Voxel* vtemp = new Voxel(&v->getSubCenterPoints()->at(k),(double)v->getLength()/2.0);
      int test = vtemp->isInsideSphere(ct, ray);
      //std::cout<<"test ="<<test<<std::endl;
      if(test!=2)
      {
        //cout << "" << endl;
      }
      else // test == 2
      {
        if(i == reso-1)
          vtemp->displayV();
        else 
          displayVoxelRecSphere(vtemp, ct,  ray, reso, i+1);
      }
    }
  }
}


void displayVoxelRecCylinder(Voxel* v,CPoint* c,CVector* vc,double r, double resolution,double cpt){
    if (cpt < resolution)
    {
        for (int i=0;i<8;i++)
            {
                Voxel* tmp = new Voxel(&v->getSubCenterPoints()->at(i),(double)v->getLength()/2.0);
                int test = tmp->isInsideCylinder(c,vc,r);

                if (test == 1)
                {
                    //tmp->displayV();

                }
                else 
                {
                    if (test == 2 && cpt == resolution -1)
                        tmp->displayV();
                    else
                        if (test == 2) displayVoxelRecCylinder(tmp,c,vc,r,resolution,cpt+1);
                }
            }
    }
}
/* */
void DisplaySOUSTRACTIONSphereCylinder(Voxel* v,CPoint* csphere,double rsphere,CPoint* ccylinder,CVector* vc,double rcylinder,double resolution,double cpt){
if (cpt < resolution)
    {
        for (int i=0;i<8;i++)
            {
                Voxel* tmp = new Voxel(&v->getSubCenterPoints()->at(i),(double)v->getLength()/2.0);
                int test = tmp->isInsideCylinder(ccylinder,vc,rcylinder);
                int test2 = tmp->isInsideSphere(csphere,rsphere);
                if ((test == 1) && (test2==1))
                {
                    DisplaySOUSTRACTIONSphereCylinder(tmp,csphere,rsphere,ccylinder,vc,rcylinder,resolution,cpt+1);
                }

                else if (test == 2 && test2 == 2)
                {
                        DisplaySOUSTRACTIONSphereCylinder(tmp,csphere,rsphere,ccylinder,vc,rcylinder,resolution,cpt+1);
                }
                else if (test == 2 && test2 != 2)
                {
                    if (cpt == resolution -1)
                        tmp->displayV();
                    else
                        DisplaySOUSTRACTIONSphereCylinder(tmp,csphere,rsphere,ccylinder,vc,rcylinder,resolution,cpt+1);
                }
            }
    }
}

void displaySOUS(CPoint* csphere,double rsphere,CPoint* ccylinder,CVector* vc,double rcylinder,double resolution) { // Point center, double rayon, double resolution
    Voxel* v;
    if (vc->Norme() > 2*rcylinder){
        v = new Voxel(ccylinder,vc->Norme());
    }
    else {
        v = new Voxel(ccylinder,5*rcylinder);
    }

    DisplaySOUSTRACTIONSphereCylinder(v, csphere, rsphere, ccylinder,vc,rcylinder,resolution, 0);
    v->drawCorners();
    }

void DisplayINTERSECTIONSphereCylinder(Voxel* v,CPoint* csphere,double rsphere,CPoint* ccylinder,CVector* vc,double rcylinder,double resolution,double cpt){
if (cpt < resolution)
    {
        for (int i=0;i<8;i++)
            {
                Voxel* tmp = new Voxel(&v->getSubCenterPoints()->at(i),(double)v->getLength()/2.0);
                int test = tmp->isInsideCylinder(ccylinder,vc,rcylinder);
                int test2 = tmp->isInsideSphere(csphere,rsphere);
                if ((test == 1) && (test2==1))
                {
                    tmp->displayV();
                }

                else if ((test == 2 && test2 !=0) || (test2 == 2 && test !=0))
                {
                    if (cpt == resolution -1)
                        tmp->displayV();
                    else
                        DisplayINTERSECTIONSphereCylinder(tmp,csphere,rsphere,ccylinder,vc,rcylinder,resolution,cpt+1);

                }
            }
    }
}

void displayINTER(CPoint* csphere,double rsphere,CPoint* ccylinder,CVector* vc,double rcylinder,double resolution) { // Point center, double rayon, double resolution
    Voxel* v;
    if (vc->Norme() > 2*rcylinder){
        v = new Voxel(ccylinder,vc->Norme());
    }
    else {
        v = new Voxel(ccylinder,5*rcylinder);
    }

    DisplayINTERSECTIONSphereCylinder(v, csphere, rsphere, ccylinder,vc,rcylinder,resolution, 0);
    v->drawCorners();
}

void DisplayUNIONSphereCylinder(Voxel* v,CPoint* csphere,double rsphere,CPoint* ccylinder,CVector* vc,double rcylinder,double resolution,double cpt){
if (cpt < resolution)
    {
        for (int i=0;i<8;i++)
            {
                Voxel* tmp = new Voxel(&v->getSubCenterPoints()->at(i),(double)v->getLength()/2.0);
                int test = tmp->isInsideCylinder(ccylinder,vc,rcylinder);
                int test2 = tmp->isInsideSphere(csphere,rsphere);
                if ((test == 2) || (test2==2))
                {
                    if (cpt == resolution -1)
                        tmp->displayV();
                    else
                        DisplayUNIONSphereCylinder(tmp,csphere,rsphere,ccylinder,vc,rcylinder,resolution,cpt+1);

                }
                else
                {
                    cout << "" << endl;
                }
            }
    }
}

void displayUNION(CPoint* csphere,double rsphere,CPoint* ccylinder,CVector* vc,double rcylinder,double resolution) { // Point center, double rayon, double resolution
     Voxel* v;
    if (vc->Norme() > 2*rcylinder){
        v = new Voxel(ccylinder,vc->Norme());
    }
    else {
        v = new Voxel(ccylinder,6*rcylinder);
    }

    DisplayUNIONSphereCylinder(v, csphere, rsphere, ccylinder,vc,rcylinder,resolution, 0);
    v->drawCorners();
}


void displaySphereAdaptatif(CPoint* ct, double ray, double reso) { // Point center, double rayon, double resolution
    Voxel* v = new Voxel(ct,2*ray);
    displayVoxelRecSphere(v, ct, ray, reso, 0);
}



void displayCylinderWithVoxel(CPoint* c,CVector* v,double r,double resolution){
    
    Voxel* vx;

    if (v->Norme() > 2*r) 
        vx = new Voxel(c,v->Norme());
    else 
        vx = new Voxel(c,10*r);
    
    displayVoxelRecCylinder(vx,c,v,r,resolution,0);
    vx->drawCorners();
}

//////////////////////////////////////////////////////////////////////////////////////////
// Fonction que vous allez modifier afin de dessiner
/////////////////////////////////////////////////////////////////////////////////////////
void render_scene()
{


    // Exercice 1
    int rayon = 10;
    glEnable(GL_DEPTH_TEST);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    // glEnable(GL_LIGHTING);
    // glEnable(GL_LIGHT0);

    glColor3f(1.0, 1.0, 1.0);
    //glMaterial(100);
    glOrtho(-20.0,20.0,-20.0,20.0,-20.0,20.0);
    gluLookAt((rayon+5)*0.25,3,(rayon+5*0.25),0,0,0,0,1,0);

    //Cylindre();
    //Cone(10);
    //Sphere(20,nbM,nbN);

    CPoint* c = new CPoint(10,0,0);
    CVector* v = new CVector(0,20,0);
    v->drawLine(10,0,0);
    CPoint* c2 = new CPoint(0,0,0);

    //CPoint proj = c->ProjectOnLine(v,c2);
    //cout << proj.getX() << " " << proj.getY() << " " << proj.getZ() << " " << endl;
   /* v->drawLine(0,0,0);
    CPoint x = c2->ProjectOnLine(v,c);

    glBegin(GL_POINTS);
    c->drawPoint();
    c2->drawPoint();
    glColor3f(0.0,1.0,0.0);
    x.drawPoint();Z
    glEnd();*/

    //DisplayVoxel(20,c);
    //displayCylinderWithVoxel(c,v,10,5);
    //displaySphereAdaptatif(c,15,5);
    //displaySOUS(c,10,c2,v,10,5);
    displayUNION(c,10,c2,v,10,8);
    //displayINTER(c,10,c2,v,10,5);
    //int nbe;

   /* 
    mesh m;

    fstream File;
    File.open("bunny.off");

    char arr[3];
    File >> arr[0];
    File >> arr[1];
    File >> arr[2];

    File >> m.nbPoints;
    File >> m.nbTriangles;
    File >> nbe;

    for (int i = 0; i < m.nbPoints; i++){
        File >> m.coordinates[3*i];
        File >> m.coordinates[3*i+1];
        File >> m.coordinates[3*i+2];
    }

    for (int j = 0; j < m.nbTriangles; j++){
        int t;
        File >> t;
        if (t == 3) {
        File >> m.indices[3*j];
        File >> m.indices[3*j+1];
        File >> m.indices[3*j+2];
        }
    }

    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer (3, GL_FLOAT, 0, m.coordinates);
    glDrawElements (GL_TRIANGLES,m.nbTriangles,GL_UNSIGNED_INT,m.indices);

    /* */


}
